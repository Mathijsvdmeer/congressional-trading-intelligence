# Development Environment Setup Guide

## Creating a Dedicated SaaS Development User on Mac

### Why Create a Separate User?
- **Cleaner environment**: No personal files mixed with dev projects
- **Faster deployments**: Avoid permission issues (Music folder, etc.)
- **Professional separation**: Keep business and personal separate
- **Claude Code CLI**: Run directly in terminal for rapid iteration

---

## Step 1: Create New Mac User

1. **System Settings** → **Users & Groups**
2. Click **Add User** (🔓 unlock with admin password if needed)
3. New Account:
   - **Account Type**: Administrator (needed for dev tools)
   - **Full Name**: "SaaS Dev" (or your preference)
   - **Account Name**: saasdev
   - **Password**: (strong password)
4. Click **Create User**

---

## Step 2: Switch to New User & Initial Setup

1. **Log out** and log in as `saasdev`
2. Complete macOS first-time setup
3. **Install Homebrew**:
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

4. **Install essential tools**:
   ```bash
   brew install git
   brew install node
   brew install python@3.11
   ```

---

## Step 3: Install Claude Code CLI

```bash
# Install Claude Code CLI globally
npm install -g @anthropic-ai/claude-code

# Verify installation
claude --version

# Login to Claude
claude auth login
```

---

## Step 4: Set Up Project Structure

```bash
# Create projects directory
mkdir -p ~/saas-projects
cd ~/saas-projects

# Clone or create Congressional Trading Intelligence
mkdir congressional-trading-intelligence
cd congressional-trading-intelligence

# Create subdirectories
mkdir backend frontend scripts docs
```

---

## Step 5: Install Python Dependencies

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install fastapi uvicorn supabase python-dotenv requests
```

---

## Step 6: Set Up Environment Variables

Create `.env` file:
```bash
cat > .env << 'EOF'
QUIVER_API_KEY=9470ba57b0b4e9ab5dae1ab77ce91573c9334cdb
SUPABASE_URL=your_supabase_url_here
SUPABASE_KEY=your_supabase_key_here
EOF
```

---

## Step 7: Install Railway CLI (for easy deploys)

```bash
npm install -g @railway/cli

# Login to Railway
railway login

# Link to project
cd ~/saas-projects/congressional-trading-intelligence/backend
railway link
```

---

## Step 8: Organize Existing Files

Transfer from your main user:

```bash
# From your MAIN user terminal, copy files
sudo cp -r /Users/mathijsvandermeer/api.py /Users/saasdev/saas-projects/congressional-trading-intelligence/backend/
sudo cp -r /Users/mathijsvandermeer/fetch_quiver_fixed.py /Users/saasdev/saas-projects/congressional-trading-intelligence/scripts/
sudo cp -r /Users/mathijsvandermeer/congress-trades-dashboard /Users/saasdev/saas-projects/congressional-trading-intelligence/frontend/
sudo cp /Users/mathijsvandermeer/.env /Users/saasdev/saas-projects/congressional-trading-intelligence/backend/

# Fix ownership
sudo chown -R saasdev:staff /Users/saasdev/saas-projects
```

---

## Recommended Workflow with Claude Code CLI

### For Backend Development:
```bash
cd ~/saas-projects/congressional-trading-intelligence/backend
claude "add automated daily data refresh using GitHub Actions"
claude "add database indexes for performance"
claude "implement error logging with Sentry"
```

### For Frontend Development:
```bash
cd ~/saas-projects/congressional-trading-intelligence/frontend
claude "add user authentication with Supabase Auth"
claude "create pricing page with Stripe integration"
claude "add email alert signup form"
```

### For Deployment:
```bash
# Deploy backend to Railway
cd backend
railway up

# Deploy frontend to Netlify
cd frontend
netlify deploy --prod
```

---

## VS Code Setup (Optional but Recommended)

1. Install VS Code: `brew install --cask visual-studio-code`
2. Install extensions:
   - Python
   - Pylance
   - ESLint
   - Prettier
   - Thunder Client (API testing)

---

## Git Configuration

```bash
git config --global user.name "Your Name"
git config --global user.email "managementmeero@gmail.com"

# Create GitHub repo
cd ~/saas-projects/congressional-trading-intelligence
git init
git add .
git commit -m "Initial commit: Congressional Trading Intelligence MVP"
```

---

## Benefits of This Setup

✅ **Faster iteration**: Claude Code CLI runs directly without context issues
✅ **Clean deployments**: No `/Users/mathijsvandermeer/Music` permission errors
✅ **Professional structure**: Organized project folders
✅ **Easy collaboration**: Can share entire user environment
✅ **Isolated testing**: Test changes without affecting personal files

---

## Next Steps After Setup

1. **Week 1: Critical Infrastructure**
   - [ ] Automated daily data refresh (cron job or GitHub Actions)
   - [ ] Custom domain setup (congresstrades.io)
   - [ ] Database indexes (trade_date, ticker, member_name)
   - [ ] Error monitoring (Sentry or LogRocket)

2. **Week 2-3: User Features**
   - [ ] User authentication (Supabase Auth)
   - [ ] Email alerts (SendGrid)
   - [ ] Pricing tiers (Free vs Premium)
   - [ ] Payment processing (Stripe)

3. **Week 4: Launch Prep**
   - [ ] Landing page
   - [ ] Beta testing with 10 users
   - [ ] Documentation
   - [ ] Marketing materials

---

## Troubleshooting

**Railway deployment fails:**
```bash
cd backend
railway up --service congress-trader-api
```

**Netlify CLI not found:**
```bash
npm install -g netlify-cli
netlify login
```

**Python module not found:**
```bash
source venv/bin/activate
pip install --break-system-packages [module-name]
```

---

## Cost Tracking

| Service | Current Plan | Monthly Cost |
|---------|-------------|--------------|
| Quiver API | Hobbyist | $10 |
| Railway | Hobby | $5 |
| Supabase | Free | $0 |
| Netlify | Free | $0 |
| **TOTAL** | | **$15/month** |

**Note**: As you scale, budget for:
- SendGrid (email): ~$15/month for 40k emails
- Custom domain: ~$12/year
- Stripe fees: 2.9% + $0.30 per transaction
- Sentry (error tracking): Free tier available

---

## Resources

- Quiver API Docs: https://www.quiverquant.com/apidocs/
- FastAPI Docs: https://fastapi.tiangolo.com/
- Supabase Docs: https://supabase.com/docs
- Railway Docs: https://docs.railway.app/
- Claude Code CLI: https://github.com/anthropics/claude-code-cli

---

**Ready to ship faster!** 🚀
